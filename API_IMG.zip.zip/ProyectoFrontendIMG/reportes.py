from sqlalchemy import func
from ModeladoDatos import db, RegistroHoras, Subtarea, Tarea, Actividad

def resumen_diario_por_actividad():
    resultados = db.session.query(
        RegistroHoras.fecha,
        Actividad.id.label("actividad_id"),
        func.sum(RegistroHoras.horas_trabajadas).label("total_horas"),
        func.count(RegistroHoras.id).label("registros")
    ).join(RegistroHoras.subtarea)\
     .join(Subtarea.tarea)\
     .join(Tarea.actividad)\
     .group_by(RegistroHoras.fecha, Actividad.id)\
     .order_by(RegistroHoras.fecha.desc())\
     .all()

    return resultados

def presupuesto_vs_ejecucion():
    actividades = Actividad.query.all()
    resumen = []

    for a in actividades:
        horas_presupuestadas = a.presupuesto  # o sumar horas_agendadas de sus subtareas
        horas_ejecutadas = db.session.query(func.sum(RegistroHoras.horas_trabajadas))\
            .join(RegistroHoras.subtarea)\
            .join(Subtarea.tarea)\
            .filter(Tarea.actividad_id == a.id)\
            .scalar() or 0

        resumen.append({
            "actividad": a.id,
            "tipo": a.tipo,
            "presupuesto": horas_presupuestadas,
            "ejecutado": horas_ejecutadas,
            "diferencia": horas_presupuestadas - horas_ejecutadas
        })

    return resumen
