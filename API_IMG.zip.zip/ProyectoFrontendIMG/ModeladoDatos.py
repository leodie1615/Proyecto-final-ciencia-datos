#Ejemplo de modelado de datos

from sqlalchemy import Column, Integer, String, Float, Date, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

# Modelo de Proyecto
class Proyecto(db.Model):
    __tablename__ = 'proyectos'

    id = db.Column(db.Integer, primary_key=True)  # ID único del proyecto
    nombre = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(50))
    contrato = db.Column(db.String(100))
    fecha_inicio = db.Column(db.Date)
    fecha_fin = db.Column(db.Date)

    # Relación: un proyecto tiene muchas actividades
    actividades = db.relationship('Actividad', backref='proyecto', lazy=True)
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.id'), nullable=False)


# Modelo de Actividad
class Actividad(db.Model):
    __tablename__ = 'actividades'

    id = db.Column(db.String(50), primary_key=True)  # ID compuesto: PROY001-01
    tipo = db.Column(db.String(10))
    presupuesto = db.Column(db.Integer)
    fecha_inicio = db.Column(db.Date)
    fecha_fin = db.Column(db.Date)

    # Clave foránea que conecta con Proyecto
    proyecto_id = db.Column(db.Integer, db.ForeignKey('proyectos.id'), nullable=False)


# Modelo de Tarea
class Tarea(db.Model):
    __tablename__ = 'tareas'

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text)
    presupuesto_horas = db.Column(db.Float)
    fecha_inicio = db.Column(db.Date)
    fecha_fin = db.Column(db.Date)

    # Clave foránea que conecta con Actividad
    actividad_id = db.Column(db.String(50), db.ForeignKey('actividades.id'), nullable=False)

    # Relación inversa (opcional, si quieres acceder desde la actividad)
    actividad = db.relationship('Actividad', backref='tareas', lazy=True)


class Subtarea(db.Model):
    __tablename__ = 'subtareas'

    id = db.Column(db.String(50), primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text)
    fecha_inicio = db.Column(db.Date)
    fecha_fin = db.Column(db.Date)
    horas_agendadas = db.Column(db.Float)  # ← nuevo campo

    # Clave foránea hacia Tarea
    tarea_id = db.Column(db.Integer, db.ForeignKey('tareas.id'), nullable=False)

    # Relación inversa
    tarea = db.relationship('Tarea', backref='subtareas', lazy=True)

class RegistroHoras(db.Model):
    __tablename__ = 'registro_horas'

    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.Date, nullable=False)
    horas_trabajadas = db.Column(db.Float, nullable=False)
    comentario = db.Column(db.Text)

    empleado_id = db.Column(db.Integer, db.ForeignKey('empleados.id'), nullable=False)
    tarea_id = db.Column(db.Integer, db.ForeignKey('tareas.id'), nullable=False)
    subtarea_id = db.Column(db.Integer, db.ForeignKey('subtareas.id'))  # Opcional

    tarea = db.relationship('Tarea', backref='registros', lazy=True)
    subtarea = db.relationship('Subtarea', backref='registros', lazy=True)


class Empleado(db.Model):
    __tablename__ = 'empleados'

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    correo = db.Column(db.String(120))
    salario = db.Column(db.Float)
    cargo = db.Column(db.String(50))

    # Relación: un empleado puede tener muchos registros de horas
    registros = db.relationship('RegistroHoras', backref='empleado', lazy=True)


class Cliente(db.Model):
    __tablename__ = 'clientes'

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    contacto = db.Column(db.String(100))
    correo = db.Column(db.String(120))
    empresa = db.Column(db.String(100))

    # Relación: un cliente puede tener muchos proyectos
    proyectos = db.relationship('Proyecto', backref='cliente', lazy=True)
