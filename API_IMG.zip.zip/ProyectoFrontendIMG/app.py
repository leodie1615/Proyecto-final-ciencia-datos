from flask import Flask, render_template, request, redirect, url_for, jsonify
from datetime import datetime
from flask_migrate import Migrate
from sqlalchemy import func, and_
from ModeladoDatos import db, Proyecto, Actividad, Empleado, Cliente, Tarea, Subtarea, RegistroHoras
from datetime import datetime
from reportes import resumen_diario_por_actividad, presupuesto_vs_ejecucion

import os
from pathlib import Path
   


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///trazabilidad.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Get the instance folder path
instance_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'instance')
db_path = os.path.join(instance_path, 'trazabilidad.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'


db.init_app(app)
migrate = Migrate(app,db)
# Crear las tablas (solo una vez)
with app.app_context():
    db.create_all()

### Landing page ###
@app.route("/")
def landing():
    return render_template("index.html")


### Formulario de creación de proyectos ###
@app.route('/crear_proyecto', methods=['GET','POST'])
def crear_proyecto():
    if request.method == 'POST':
        # Recibir datos del proyecto
        nombre = request.form.get('nombre')
        id_project = request.form.get('project_id')
        tipo = request.form.get('tipo')
        cliente_id = request.form.get('cliente_id')
        contrato = request.form.get('contrato')
        # Convertir strings a objetos date
        fecha_inicio = datetime.strptime(request.form.get('fecha_inicio'), '%Y-%m-%d').date()
        fecha_fin = datetime.strptime(request.form.get('fecha_fin'), '%Y-%m-%d').date()

        # Crear y guardar el proyecto
        proyecto = Proyecto(
            id = id_project,
            nombre=nombre,
            tipo=tipo,
            cliente_id=cliente_id,
            contrato=contrato,
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin
        )
        db.session.add(proyecto)
        db.session.commit()

        # Obtener el ID del proyecto recién creado
        id_proyecto = proyecto.id

        # Recibir listas de actividades
        ids = request.form.getlist('actividad_id')
        tipos = request.form.getlist('actividad_tipo')
        presupuestos = request.form.getlist('actividad_presupuesto')
        fechas_inicio = request.form.getlist('actividad_fecha_inicio')
        fechas_fin = request.form.getlist('actividad_fecha_fin')

        # Guardar cada actividad
        for i in range(len(ids)):
            # Limpiar presupuesto (quitar $ y puntos)
            presupuesto_limpio = presupuestos[i].replace("$", "").replace(".", "").replace(",", "").strip()
            presupuesto = int(presupuesto_limpio)
            fecha_inicio_act = datetime.strptime(fechas_inicio[i], '%Y-%m-%d').date()
            fecha_fin_act = datetime.strptime(fechas_fin[i], '%Y-%m-%d').date()
            actividad = Actividad(
                id=ids[i],
                tipo=tipos[i],
                presupuesto=presupuesto,
                fecha_inicio=fecha_inicio_act,
                fecha_fin=fecha_fin_act,
                proyecto_id=id_proyecto
            )
            db.session.add(actividad)

        db.session.commit()

        return redirect(url_for("landing"))
    clientes = Cliente.query.all()
    return render_template('crear_proyecto.html', clientes=clientes)

### visualización de proyectos ###

@app.route('/proyectos')
def listar_proyectos():
    proyectos = Proyecto.query.all()
    return render_template('listar_proyectos.html', proyectos=proyectos)

@app.route("/crear_empleado", methods=["GET", "POST"])
def crear_empleado():
    if request.method == "POST":
        salario_s = request.form.get("salario", "")
        salario_limpio = salario_s.replace("$", "").replace(".", "").replace(",", "").strip()
        
        try:
            salario = int(salario_limpio)
        except ValueError:
            return "⚠️ Error: el salario no tiene un formato numérico válido", 400

        nuevo = Empleado(
            nombre=request.form.get("nombre"),
            correo=request.form.get("correo"),
            salario=salario,
            cargo=request.form.get("cargo")
        )
        db.session.add(nuevo)
        db.session.commit()
        return redirect(url_for("landing")) 
    return render_template("crear_empleado.html")


@app.route('/empleados')
def listar_empleados():
    empleados = Empleado.query.all()
    return render_template('listar_empleados.html', empleados=empleados)

@app.route("/crear_cliente", methods=["GET", "POST"])
def crear_cliente():
    if request.method == "POST":
        nuevo = Cliente(
            nombre=request.form.get("nombre"),
            empresa=request.form.get("empresa"),
            contacto=request.form.get("contacto"),
            correo=request.form.get("correo")
        )
        db.session.add(nuevo)
        db.session.commit()
        return redirect(url_for("landing"))
    return render_template("crear_cliente.html")

@app.route("/clientes")
def listar_clientes():
    clientes = Cliente.query.all()
    return render_template("listar_clientes.html", clientes=clientes)

@app.route("/crear_tarea", methods=["GET", "POST"])
def crear_tarea():
    if request.method == "POST":
        # Datos de la tarea principal
        id_tarea = request.form.get("id")
        nombre = request.form.get("nombre")
        descripcion = request.form.get("descripcion")
        actividad_id = request.form.get("actividad_id")

        nueva_tarea = Tarea(
            id = id_tarea,
            nombre=nombre,
            descripcion=descripcion,
            actividad_id=actividad_id
        )
        db.session.add(nueva_tarea)
        db.session.commit()

        # Subtareas
        nombres_sub = request.form.getlist("sub_nombre")
        horas_sub = request.form.getlist("sub_horas")

        for i in range(len(nombres_sub)):
            numero = str(i + 1).zfill(3)
            id_subtarea = f"{nueva_tarea.id}{numero}"
            horas_agendadas = float(horas_sub[i])
            subtarea = Subtarea(
                id=id_subtarea,
                nombre=nombres_sub[i],
                descripcion="",  # puedes agregar campo si lo deseas
                fecha_inicio=None,
                fecha_fin=None,
                horas_agendadas=horas_agendadas,
                tarea_id=nueva_tarea.id
            )
            db.session.add(subtarea)
            db.session.flush()  # para obtener el ID antes de commit

            registro = RegistroHoras(
                fecha=datetime.today().date(),
                horas_trabajadas=float(horas_sub[i]),
                comentario="Horas agendadas",
                tarea_id=nueva_tarea.id,
                subtarea_id=subtarea.id,
                empleado_id=1  # puedes ajustar esto según el contexto
            )
            db.session.add(registro)

        db.session.commit()
        return redirect(url_for("landing"))

    proyectos = Proyecto.query.all()
    actividades = Actividad.query.all()
    return render_template("crear_tarea.html", proyectos=proyectos, actividades=actividades)

@app.route("/tareas")
def listar_tareas():
    tareas = Tarea.query.all()
    return render_template("listar_tareas.html", tareas=tareas)

@app.route("/cargar_horas", methods=["GET", "POST"])
def cargar_horas():
    if request.method == "POST":
        empleado_id = request.form.get("empleado_id")
        tarea_id = request.form.get("tarea_id")
        subtarea_id = request.form.get("subtarea_id")
        horas_trabajadas = float(request.form.get("horas_trabajadas"))
        horas_extra = float(request.form.get("horas_extra"))
        comentario = request.form.get("comentario")

        registro = RegistroHoras(
            fecha=datetime.today().date(),
            horas_trabajadas=horas_trabajadas + horas_extra,
            comentario=comentario,
            empleado_id=empleado_id,
            tarea_id=tarea_id,
            subtarea_id=subtarea_id
        )
        db.session.add(registro)
        db.session.commit()
        return redirect(url_for("landing"))

    empleados = Empleado.query.all()
    proyectos = Proyecto.query.all()
    # Obtener todas las tareas con sus actividades cargadas para poder filtrar por proyecto
    tareas = Tarea.query.join(Actividad).all()
    return render_template("cargar_horas.html", empleados=empleados, proyectos=proyectos, tareas=tareas, hoy=datetime.today().date())

@app.route("/api/subtareas_por_tarea/<tarea_id>")
def subtareas_por_tarea(tarea_id):
    subtareas = Subtarea.query.filter_by(tarea_id=tarea_id).all()
    return jsonify([{"id": s.id, "nombre": s.nombre} for s in subtareas])

@app.route("/api/siguiente_id_proyecto")
def siguiente_id_proyecto():
    """Retorna el siguiente ID disponible para un nuevo proyecto"""
    try:
        # Obtener el ID más grande de la tabla proyectos
        max_id = db.session.query(func.max(Proyecto.id)).scalar()
        
        # Si no hay proyectos, empezar con 1
        if max_id is None:
            siguiente_id = 1
        else:
            siguiente_id = max_id + 1
        
        return jsonify({"siguiente_id": siguiente_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/siguiente_id_tarea")
def siguiente_id_tarea():
    """Retorna el siguiente ID disponible para una nueva tarea"""
    try:
        # Obtener el ID más grande de la tabla tareas
        max_id = db.session.query(func.max(Tarea.id)).scalar()
        
        # Si no hay tareas, empezar con 1
        if max_id is None:
            siguiente_id = 1
        else:
            siguiente_id = max_id + 1
        
        return jsonify({"siguiente_id": siguiente_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/panel_horas")
def panel_costos():
    # Query para obtener todas las horas trabajadas con información completa
    # Equivalente a: SELECT py.nombre, act.tipo, act.id, tar.nombre, sub.nombre, 
    #                hor.horas_trabajadas, emp.nombre, hor.fecha
    # FROM proyectos py
    # JOIN actividades act ON py.id = act.proyecto_id
    # left JOIN tareas tar ON act.id = tar.actividad_id
    # left JOIN subtareas sub ON tar.id = sub.tarea_id
    # left JOIN registro_horas hor ON tar.id = hor.tarea_id and sub.id = hor.subtarea_id
    # left JOIN empleados emp ON hor.empleado_id = emp.id
    # ORDER BY 1,3,4,5
    horas = db.session.query(
        Proyecto.nombre.label('proyecto_nombre'),
        Actividad.tipo.label('actividad_tipo'),
        Actividad.id.label('actividad_id'),
        Tarea.nombre.label('tarea_nombre'),
        Subtarea.nombre.label('subtarea_nombre'),
        RegistroHoras.horas_trabajadas,
        Empleado.nombre.label('empleado_nombre'),
        RegistroHoras.fecha
    ).join(Actividad, Proyecto.id == Actividad.proyecto_id)\
     .join(Tarea, Actividad.id == Tarea.actividad_id)\
     .join(Subtarea, Tarea.id == Subtarea.tarea_id)\
     .join(RegistroHoras, and_(Tarea.id == RegistroHoras.tarea_id, Subtarea.id == RegistroHoras.subtarea_id))\
     .join(Empleado, RegistroHoras.empleado_id == Empleado.id)\
     .order_by(Proyecto.nombre, Actividad.id, Tarea.nombre, Subtarea.nombre)\
     .all()
    
    return render_template("panel_horas.html", horas=horas)


if __name__ == '__main__':
    app.run(debug=True)