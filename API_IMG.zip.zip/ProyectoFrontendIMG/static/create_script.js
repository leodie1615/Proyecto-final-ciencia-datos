/* 
 Este archivo maneja la logica de los formularios de creacion de cosas.

Variables globales porque no se donde mas ponerlas 
*/

let contadorActividades = 0;
let contadorSubtareas = 1;

/* ============================================
   FUNCIONES PARA CREAR PROYECTOS
   ============================================ */
function agregarActividad() {
    const container = document.getElementById('actividades');
    const idProyecto = document.getElementById('project_id').value.trim();

    if (!idProyecto) {
        alert("Por favor ingresa el ID del proyecto antes de agregar actividades.");
        return;
    }

    contadorActividades += 1;
    const consecutivo = String(contadorActividades).padStart(2, '0');
    const idActividad = `${idProyecto}-${consecutivo}`;
    const actividadId = `actividad-${contadorActividades}`;

    const div = document.createElement('div');
    div.id = actividadId;
    div.className = 'actividad-container';
    div.innerHTML = `
        <fieldset style="position: relative; margin-bottom: 20px; padding: 10px; border: 1px solid #ccc;">
            <button type="button" class="btn-eliminar-actividad" onclick="eliminarActividad('${actividadId}')" title="Eliminar actividad">×</button>
            <legend>Actividad ${consecutivo}</legend>

            <label>ID Actividad:</label>
            <input type="text" name="actividad_id" value="${idActividad}" readonly><br><br>

            <label>Tipo de actividad:</label>
            <select name="actividad_tipo" required>
                <option value="A1">A1</option>
                <option value="A2">A2</option>
                <option value="A3">A3</option>
                <option value="A4">A4</option>
                <option value="A5">A5</option>
                <option value="A6">A6</option>
            </select><br><br>

            <label>Presupuesto (COP):</label>
            <input type="text" name="actividad_presupuesto" class="moneda" placeholder="$0.000" oninput="formatearMoneda(this)" required><br><br>

            <label>Fecha de inicio:</label>
            <input type="date" name="actividad_fecha_inicio" required><br><br>

            <label>Fecha de fin:</label>
            <input type="date" name="actividad_fecha_fin" required><br><br>
        </fieldset>
    `;
    container.appendChild(div);
}

function formatearMoneda(input) {
    let valor = input.value.replace(/\D/g, "");
    valor = new Intl.NumberFormat('es-CO').format(valor);
    input.value = "$" + valor;
}

/**
 * Elimina una actividad del formulario
 * @param {string} actividadId - El ID del contenedor de la actividad a eliminar
 */
function eliminarActividad(actividadId) {
    const actividad = document.getElementById(actividadId);
    if (actividad) {
        // Confirmar antes de eliminar
        if (confirm('¿Estás seguro de que deseas eliminar esta actividad?')) {
            actividad.remove();
        }
    }
}

/**
 * Obtiene el siguiente ID disponible para un nuevo proyecto desde la API
 * y lo asigna al campo de ID del proyecto
 */
async function obtenerSiguienteIdProyecto() {
    try {
        const response = await fetch('/api/siguiente_id_proyecto');
        const data = await response.json();
        
        if (data.error) {
            console.error('Error al obtener ID:', data.error);
            alert('Error al obtener el ID del proyecto. Por favor, recarga la página.');
            return;
        }
        
        // Asignar el ID al campo
        const projectIdField = document.getElementById('project_id');
        if (projectIdField) {
            projectIdField.value = data.siguiente_id;
        }
    } catch (error) {
        console.error('Error al obtener ID del proyecto:', error);
        alert('Error al obtener el ID del proyecto. Por favor, recarga la página.');
    }
}

/* ============================================
   FUNCIONES PARA CREAR TAREAS
   ============================================ */



/**
 * Filtra las actividades disponibles según el proyecto seleccionado
 */
function filtrarActividades() {
    const proyectoId = document.getElementById("proyecto").value;
    const actividades = document.querySelectorAll("#actividad_id option");
    const actividadSelect = document.getElementById("actividad_id");

    // Mostrar todas las opciones si no hay proyecto seleccionado
    if (!proyectoId) {
        actividades.forEach(opt => {
            if (opt.value !== "") {
                opt.style.display = "block";
            }
        });
        actividadSelect.value = "";
        return;
    }

    // Filtrar actividades por proyecto
    actividades.forEach(opt => {
        if (opt.value === "") {
            opt.style.display = "block"; // Mantener la opción por defecto visible
        } else {
            opt.style.display = opt.dataset.proyecto === proyectoId ? "block" : "none";
        }
    });

    // Limpiar selección de actividad
    actividadSelect.value = "";
}

/**
 * Agrega una nueva subtarea al formulario
 */
function agregarSubtarea() {
    contadorSubtareas += 1;
    const subtareaId = `subtarea-${contadorSubtareas}`;
    const container = document.getElementById("subtareas");
    
    const div = document.createElement("div");
    div.id = subtareaId;
    div.className = "subtarea";
    div.innerHTML = `
        <button type="button" class="btn-eliminar-subtarea" onclick="eliminarSubtarea('${subtareaId}')" title="Eliminar subtarea">×</button>
        <label>Nombre subtarea:</label>
        <input type="text" name="sub_nombre" required>
        <label>Horas agendadas:</label>
        <input type="number" step="0.1" name="sub_horas" required>
    `;
    container.appendChild(div);
}

/**
 * Elimina una subtarea del formulario
 * @param {string} subtareaId - El ID del contenedor de la subtarea a eliminar
 */
function eliminarSubtarea(subtareaId) {
    const subtarea = document.getElementById(subtareaId);
    if (subtarea) {
        // Confirmar antes de eliminar
        if (confirm('¿Estás seguro de que deseas eliminar esta subtarea?')) {
            subtarea.remove();
        }
    }
}

/**
 * Obtiene el siguiente ID disponible para una nueva tarea desde la API
 * y lo asigna al campo de ID de la tarea
 */
async function obtenerSiguienteIdTarea() {
    try {
        const response = await fetch('/api/siguiente_id_tarea');
        const data = await response.json();
        
        if (data.error) {
            console.error('Error al obtener ID:', data.error);
            alert('Error al obtener el ID de la tarea. Por favor, recarga la página.');
            return;
        }
        
        // Asignar el ID al campo
        const tareaIdField = document.getElementById('tarea_id');
        if (tareaIdField) {
            tareaIdField.value = data.siguiente_id;
        }
    } catch (error) {
        console.error('Error al obtener ID de la tarea:', error);
        alert('Error al obtener el ID de la tarea. Por favor, recarga la página.');
    }
}

// Cargar los IDs automáticamente cuando la página se carga
document.addEventListener('DOMContentLoaded', function() {
    // Cargar ID de proyecto si existe el campo
    if (document.getElementById('project_id')) {
        obtenerSiguienteIdProyecto();
    }
    // Cargar ID de tarea si existe el campo
    if (document.getElementById('tarea_id')) {
        obtenerSiguienteIdTarea();
    }
});

/* ============================================
   FUNCIONES PARA CARGAR HORAS
   ============================================ */

/**
 * Filtra las tareas disponibles según el proyecto seleccionado
 */
function filtrarTareas() {
    const proyectoId = document.getElementById("proyecto_id").value;
    const tareas = document.querySelectorAll("#tarea_id option");
    const tareaSelect = document.getElementById("tarea_id");

    // Mostrar todas las opciones si no hay proyecto seleccionado
    if (!proyectoId) {
        tareas.forEach(opt => {
            if (opt.value !== "") {
                opt.style.display = "block";
            }
        });
        tareaSelect.value = "";
        cargarSubtareas(); // Limpiar subtareas
        return;
    }

    // Filtrar tareas por proyecto
    tareas.forEach(opt => {
        if (opt.value === "") {
            opt.style.display = "block"; // Mantener la opción por defecto visible
        } else {
            opt.style.display = opt.dataset.proyecto === proyectoId ? "block" : "none";
        }
    });

    // Limpiar selección de tarea y subtarea
    tareaSelect.value = "";
    cargarSubtareas();
}

/**
 * Carga las subtareas disponibles para la tarea seleccionada
 */
function cargarSubtareas() {
    const tareaId = document.getElementById("tarea_id").value;
    const subtareaSelect = document.getElementById("subtarea_id");

    if (!tareaId) {
        subtareaSelect.innerHTML = '<option value="">-- Selecciona subtarea --</option>';
        return;
    }

    fetch("/api/subtareas_por_tarea/" + tareaId)
        .then(res => res.json())
        .then(data => {
            subtareaSelect.innerHTML = '<option value="">-- Selecciona subtarea --</option>';
            data.forEach(s => {
                const opt = document.createElement("option");
                opt.value = s.id;
                opt.textContent = `${s.id} - ${s.nombre}`;
                subtareaSelect.appendChild(opt);
            });
        })
        .catch(error => {
            console.error('Error al cargar subtareas:', error);
            subtareaSelect.innerHTML = '<option value="">-- Error al cargar subtareas --</option>';
        });
}
