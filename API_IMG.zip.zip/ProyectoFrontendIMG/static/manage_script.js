/* 
 Este archivo maneja la logica de las pantallas de visualizacion de cosas.
 Incluye la logica de modificar y eliminar cosas.
 
*/

/* ============================================
   FUNCIONES PARA MODIFICAR PROYECTOS
   ============================================ */
   